<!DOCTYPE html>
<html lang="en">
<?php
require_once("config.php");
require_once("class_session.php");

session_start();
$link = mysqli_connect("localhost","root","root","hola");
$username=$_SESSION['username'];
$prod=$_GET['prod'];
$sql="SELECT * FROM Orders WHERE Username='$username' AND ProductID=$prod AND DeliveryStatus='YES'";
$cnt=mysqli_num_rows(mysqli_query($link,$sql));
if($cnt==0)
{
    echo $_POST['rating'];
echo $_POST['comment'];
    ?><p style="margin-left:100px;"><?php echo "You must first buy the product or wait for the product delivery in order to leave a review.";?></p><?php
    ?><a style="margin-left:100px;" href="product.php?prod=<?php echo $_GET['prod']?>">Go back</a><?php
}
else{
if(isset($_GET['done']) && isset($_SESSION['username'])){
$rating=$_POST['rating'];
$comment=$_POST['comment'];
$s="INSERT INTO Review (Username,ProductID,Rating,Comment) VALUES('$username','$prod',$rating,'$comment')";
    if(mysqli_query($link,$s))
    {
        echo "Review added successfully!";
        ?><a style="margin-left:100px;" href="product.php?prod=<?php echo $_GET['prod'];?>">Go back</a><?php
    }
    else
    {
        ?> <p style="margin-left:100px;"> <?php echo "You've already added a review."; ?> </p> <?php
        ?><a style="margin-left:100px;" href="product.php?prod=<?php echo $_GET['prod'];?>">Go back</a><?php
    }
}

?>


<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Register</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/portfolio-item.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

<style>

    body{
        background:url('Images/yo.jpg');
    }
    form#tab{
        margin-left:100px;
    }

    </style>
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="store.php">Home</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div id="center">
        <div id="navigation">
            <div id="pagenav">
            <form id="tab" action="review.php?prod=<?php echo $prod ?>&done" method="post";>
            <fieldset>
                <legend>Leave a review</legend>
            Comment:<br>
                        <input type="text" name="comment"><br><br>
            Rating:<br>
                        <input type="number" min='1' max='5' default="5" name="rating"><br><br>
            <input class="button" type="submit" value="Submit">
            <input class="button" type="reset" value="Reset">
            </fieldset>
            </form>
            </div>
        </div>
    </div><?php } ?>

        <!-- Portfolio Item Heading -->
       
        <!-- /.row -->

        <!-- Portfolio Item Row -->


        <!-- Related Projects Row -->
        
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p style="margin-left:100px">Copyright &copy; CartKings 2016</p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
