<?php

require_once("config.php");

$link = mysql_connect(HOST, USER, PW);
if (!$link) {
	echo "h";
	die ("Error connecting to the database: " . mysql_error());
}

$db_selected = mysql_select_db(DB,$link);
if (!$db_selected) {
	die ("Error selecting the database: " . mysql_error());
}

/* Get the variables from the registration form */
$name = mysql_real_escape_string($_POST['name']);
$phone_no = mysql_real_escape_string($_POST['phone_no']);
$password = mysql_real_escape_string($_POST['password']);
$pan_no = mysql_real_escape_string($_POST['pan_no']);
$aadhar_no = mysql_real_escape_string($_POST['aadhar_no']);
$username = mysql_real_escape_string($_POST['username']);
$email = mysql_real_escape_string($_POST['email']);

/* Check section parameters */
$text_match = "/^[a-zA-Z][a-z]*/";
$email_match = "/^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/";

$error_flag = false;


?>
	<div id="center">
		<div id="navigation">
			<div id="pagenav">
			<?php
			/* Check the registration form parameteres */
			if($name == '' || $username == '' || $password == '' || $email == ''|| $pan_no == ''|| $aadhar_no == ''|| $phone_no == '') {
				echo "Error: one or more form fields are empty!";
				$error_flag = true; 
				mysql_close(); ?>
				<br><br>
				<a href="registerseller.html">Go back to the registration form</a>			
			<?php }

			if($error_flag == false && ( !preg_match($text_match, $name) || !preg_match($text_match, $username) || !preg_match($email_match, $email) )) {
				echo "Error: one or more form fields are in not valid format!";
				$error_flag = true; 
				mysql_close(); ?>
                                <br><br>
                                <a href="registerseller.html">Go back to the registration form</a>
			<?php }

			if($error_flag == false && ( strlen($password) < 6 || strlen($password) > 20 )) {
				echo "The password must be at least 6 characters (max 20 characters)!";
				$error_flag = true;
				mysql_close(); ?>
				<br><br>
                                <a href="registerseller.html">Go back to the registration form</a>
			<?php } 
			
			if($error_flag == false) {
				/* Check if the username already exists (lock the users database table) */
				if(!mysql_query("LOCK TABLES Seller WRITE")) {
	           			mysql_close();
		    			print mysql_error();
	        		}

				/* LIMIT 1: stop searching if you find a match */
				$query = "SELECT Username FROM Seller WHERE Username = '".$username."' LIMIT 1";
				$result = mysql_query($query);

				if (!$result) {
	            			mysql_query("UNLOCK TABLES");
	            			mysql_close();
		    			print mysql_error();
	        		}
	
				/* The usernmae already exists (unlock the user database table) */
				if(mysql_num_rows($result) != 0) { 
					mysql_query("UNLOCK TABLES");
		        		mysql_close();
					echo "The username $username is already in use. Please choose another username";
					$error_flag = true ?>
					<br><br>
					<a href="registerseller.html">Go back to the registration form</a>
					<?php } ?>

				<?php $query = "SELECT Email FROM Seller WHERE Email = '".$email."' LIMIT 1";
				$result = mysql_query($query);

				if (!$result) {
	            			mysql_query("UNLOCK TABLES");
	            			mysql_close();
		    			print mysql_error();
	        		}
	
				/* The usernmae already exists (unlock the user database table) */
				if(mysql_num_rows($result) != 0) { 
					mysql_query("UNLOCK TABLES");
		        		mysql_close();
					echo "The email $email is already in use. Please choose another email address";
					$error_flag = true ?>
					<br><br>
					<a href="registerseller.html">Go back to the registration form</a>	
				<?php }
			//}
			}

			if($error_flag == false) {
				/* Insert the user data in the database */
				$query = sprintf("INSERT INTO Seller (Name_Seller, Username, Pan_Number, Aadhar_Number, Email, Password, Phone_Number ) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s')", $name, $username, $pan_no, $aadhar_no, $email, $password, $phone_no);
				$result = mysql_query($query);

				if (!$result) {
					mysql_query("UNLOCK TABLES");
					mysql_close();
					print mysql_error();
                }
                              //  print mysqli_error();

				/* Registration Successful */
				mysql_query("UNLOCK TABLES");
			//	header('Location: ../index.php?succesful');
				echo "Registration successful!";?>
				<br><br>
				Please <a href="../index.php">Login</a> to access the store.
 			<?php
			}
			?>
			</div>
		</div>
	</div>
<?php


?>
