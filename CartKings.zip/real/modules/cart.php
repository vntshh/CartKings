<!DOCTYPE html>
<html lang="en">
<?php

require_once("config.php");
require_once("class_session.php");

session_start();

if(isset($_GET['logout'])) {
    session_destroy();
    $_SESSION = NULL;
    header('Location: store.php');
}
if(isset($_GET['logout1'])) {
    session_destroy();
    $_SESSION = NULL;
    header('Location: products.php?logout1');
}
 if(isset($_GET['categoryi'])){
        $_POST['categoryi']=$_GET['categoryi'];
    }
if(isset($_GET['succesful'])) {
    echo "yo";
    ?><div class="alert alert-success">
  <strong>Success!</strong>
</div><?php
}

$link = mysql_connect(HOST, USER, PW);
if (!$link) {
    die ("Error connecting to the database: " . mysql_error());
}

$db_selected = mysql_select_db(DB,$link);
if (!$db_selected) {
    die ("Error selecting the database: " . mysql_error());
}

$error_flag = false;

//include("header.html");
?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Shop Homepage - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
    body{
    background:url('Images/yo.jpg');
    padding:50px;
}

#login-dp{
    min-width: 250px;
    padding: 14px 14px 0;
    overflow:hidden;
    background-color:rgba(255,255,255,.8);
}
#login-dp .help-block{
    font-size:12px    
}
#login-dp .bottom{
    background-color:rgba(255,255,255,.8);
    border-top:1px solid #ddd;
    clear:both;
    padding:14px;
}
#login-dp .social-buttons{
    margin:12px 0    
}
#login-dp .social-buttons a{
    width: 49%;
}
#login-dp .form-group {
    margin-bottom: 10px;
}
.btn-fb{
    color: #fff;
    background-color:#3b5998;
}
.btn-fb:hover{
    color: #fff;
    background-color:#496ebc 
}
.btn-tw{
    color: #fff;
    background-color:#55acee;
}
.btn-tw:hover{
    color: #fff;
    background-color:#59b5fa;
}
@media(max-width:768px){
    #login-dp{
        background-color: inherit;
        color: #fff;
    }
    #login-dp .bottom{
        background-color: inherit;
        border-top:0 none;
    }
}

    </style>

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
       <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="store.php" style="font-size:175%;">CartKings</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li style="margin-left:20px;"><a href="#">Home</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Info<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
          </ul>
        </li>
      </ul>
      
            <?php
                    //LOGIN PART
                if(!empty($_POST['username']) && !empty($_POST['password']) && !isset($_SESSION['username'])) {
                    $username = mysql_real_escape_string($_POST['username']);
                    $password = mysql_real_escape_string($_POST['password']);
                    $_POST['username']=NULL;
                    $_POST['password']=NULL;
                    /* LIMIT 1: stop searching if you find a match */
                    $query = "SELECT * FROM Customer WHERE Username='".$username."' AND Password='".$password."' LIMIT 1";
                    $result = mysql_query($query);


                   



                   // $_SESSION['log']=1;
                   // echo  $_SESSION['log'];


                    if(!$result) {

                        die ("Query error $query: " . mysql_error());
                    }
                    
                    if(!mysql_num_rows($result)) {
                        mysql_close();
                        //echo $username.$password;
?>
                       
                       <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Login</b> <span class="caret"></span></a>
            <ul id="login-dp" class="dropdown-menu">
                <li>
                     <div class="row">
                            <div class="col-md-12">
                                 <form class="form" role="form" method="post" action="store.php" accept-charset="UTF-8" id="login-nav">
                                        <div class="form-group">
                                             <label class="sr-only" for="exampleInputEmail2">Email address</label>
                                             <input type="text" name="username" class="form-control" id="exampleInputEmail2" placeholder="Email address" required>
                                        </div>
                                        <div class="form-group">
                                             <label class="sr-only" for="exampleInputPassword2">Password</label>
                                        
                                             <input type="password" name="password" class="form-control" id="exampleInputPassword2" placeholder="Password" required>
                                        </div>
                                        <div class="form-group">
                                             <button type="submit" class="btn btn-primary btn-block">Sign in</button>
                                        </div>
                                 </form>
                            </div>
                            <div class="bottom text-center">
                                New here ? <a href="#"><b>Join Us</b></a>
                            </div>
                            </div>
                     </div>
                </li>
            </ul>
        </li>
      </ul>

                       <?php
                       header('Location: ../index.php?wrong');
                        

                        $error_flag = true;
                    }
                    else {
                        /* Setup the SESSION */
                        $_SESSION['username'] = $username;
                        ?>
                                 
                <?php
                    } header("HTTP/1.1 302 Found");
header('Location: store.php');
                }
                else if(isset($_SESSION['username'])) {
                    ?>
                   
                        
                <?php
                }
                else {

                    ?>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Login</b> <span class="caret"></span></a>
            <ul id="login-dp" class="dropdown-menu">
                <li>
                     <div class="row">
                            <div class="col-md-12">
                                 <form class="form" role="form" method="post" action="store.php" accept-charset="UTF-8" id="login-nav">
                                        <div class="form-group">
                                             <label class="sr-only" for="exampleInputEmail2">Email address</label>
                                             <input type="text" name="username" class="form-control" id="exampleInputEmail2" placeholder="Email address" required>
                                        </div>
                                        <div class="form-group">
                                             <label class="sr-only" for="exampleInputPassword2">Password</label>
                                        
                                             <input type="password" name="password" class="form-control" id="exampleInputPassword2" placeholder="Password" required>
                                        </div>
                                        <div class="form-group">
                                             <button type="submit" class="btn btn-primary btn-block">Sign in</button>
                                        </div>
                                 </form>
                            </div>
                            <div class="bottom text-center">
                                New here ? <a href="#"><b>Join Us</b></a>
                            </div>
                            </div>
                     </div>
                </li>
            </ul>
        </li>
      </ul>
      <?php




                    //session_regenerate_id();
                    //mysql_close();
                    //echo "Session Expired!";
                    //header('Location: ../index.php');
                    //$error_flag = true;             
                }
?>
                


               


               
               
                <?php

                //hello part dropdown

                 if(isset($_SESSION['username'])): ?>
                                <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><b><?php
                                                                    print "Hello ".$_SESSION['username']; ?></b> <span class="caret"></span></a>
            <ul id="login-dp" class="dropdown-menu">

                     <li><a href="order.php">My Orders</a></li>
            <li><a href="cart.php">My Cart</a></li>
            <li><a href="store.php?logout1">Logout</a></li>
            </ul>
        </li>
      </ul>
                <?php endif; 

                //search container
                ?>
            <li>
                          <div class="search-container pull-right" >
                          <div style="margin-top:12px;">
                    <form id="search" action="store.php" method="post" autocomplete="off">


                    <?php if(!isset($_POST['categoryi'])): ?>
                        <input name="search" type="text" placeholder="search" value="" tabindex="1" autocomplete="off" maxlength="240" style="width: 188px; max-width: 188px;">
                    <?php endif;?>
                    <?php if(isset($_POST['categoryi'])):?>
                        <input type="hidden" name="categoryi" value="<?php print $_POST['categoryi'];?>" >
                        <input name="search" type="text" placeholder="search" value="" tabindex="1" autocomplete="off" maxlength="240" style="width: 188px; max-width: 188px;">
                    <?php endif;?>

                    </form>
                        </div></div>
            </li></ul>
                    
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div>
    </nav>


    <br>
    <br>
    <style>
/*  
    Side Navigation Menu V2, RWD
    ===================
    License:
    http://goo.gl/EaUPrt
    ===================
    Author: @PableraShow

 */

@charset "UTF-8";
@import url(http://fonts.googleapis.com/css?family=Open+Sans:300,400,700);

body {
  font-family: 'Open Sans', sans-serif;
  font-weight: 300;
  line-height: 1.42em;
  color:#A7A1AE;
  background-color:#1F2739;
}

h1 {
  font-size:3em; 
  font-weight: 300;
  line-height:1em;
  text-align: center;
  color: #4DC3FA;
}


.blue { color: #185875; }
.yellow { color: #FFF842; }

.container th h1 {
      font-weight: bold;
      font-size: 1em;
  text-align: left;
  color: #185875;
}

.container td {
      font-weight: normal;
      font-size: 1em;
  -webkit-box-shadow: 0 2px 2px -2px #0E1119;
       -moz-box-shadow: 0 2px 2px -2px #0E1119;
            box-shadow: 0 2px 2px -2px #0E1119;
}

.container {
      text-align: left;
      overflow: hidden;
      width: 80%;
      margin: 0 auto;
  display: table;
  padding: 0 0 8em 0;
}

.container td, .container th {
      padding-bottom: 2%;
      padding-top: 2%;
  padding-left:2%;  
}

/* Background-color of the odd rows */
.container tr:nth-child(odd) {
      background-color: #323C50;
}

/* Background-color of the even rows */
.container tr:nth-child(even) {
      background-color: #2C3446;
}

.container th {
      background-color: #1F2739;
}

.container td:first-child { color: #FB667A; }

.container tr:hover {
   background-color: #464A52;
-webkit-box-shadow: 0 6px 6px -6px #0E1119;
       -moz-box-shadow: 0 6px 6px -6px #0E1119;
            box-shadow: 0 6px 6px -6px #0E1119;
}

.container td:hover {
  background-color: #FFF842;
  color: #403E10;
  font-weight: bold;
  
  box-shadow: #7F7C21 -1px 1px, #7F7C21 -2px 2px, #7F7C21 -3px 3px, #7F7C21 -4px 4px, #7F7C21 -5px 5px, #7F7C21 -6px 6px;
  transform: translate3d(6px, -6px, 0);
  
  transition-delay: 0s;
      transition-duration: 0.4s;
      transition-property: all;
  transition-timing-function: line;
}

@media (max-width: 800px) {
.container td:nth-child(4),
.container th:nth-child(4) { display: none; }
}
    </style>

    <style>


.animate
{
    transition: all 0.1s;
    -webkit-transition: all 0.1s;
}

.action-button
{
    position: relative;
    padding: 10px 40px;
  margin: 0px 10px 10px 0px;
  float: left;
    border-radius: 10px;
    font-family: 'Pacifico', cursive;
    font-size: 25px;
    color: #FFF;
    text-decoration: none;  
}

.green
{
    background-color: #82BF56;
    border-bottom: 5px solid #669644;
    text-shadow: 0px -2px #669644;
}


.action-button:active
{
    transform: translate(0px,5px);
  -webkit-transform: translate(0px,5px);
    border-bottom: 1px solid;
}

.tattt
{
    text-align:center;
margin:auto;
}

    </style>

<?php

if(!empty($_GET["action"])) {
switch($_GET["action"]) {
    case "add":
    {
        $tat = $_GET["pid"];
        $result = mysql_query("UPDATE Cart SET Total_Quantity=Total_Quantity+1 WHERE ProdID='$tat'");
    }    
    break;
    case "sub":
    {
        $tat = $_GET["pid"];
        $result = mysql_query("UPDATE Cart SET Total_Quantity=Total_Quantity-1 WHERE ProdID='$tat' and Total_Quantity>=1");
    }    
    break;
    case "rem":
    {
        $tat = $_GET["pid"];
        $result = mysql_query("DELETE FROM Cart WHERE ProdID='$tat'");
    }
    break;  
}
}
?>
    <?php
    $ppp=$_SESSION['username'];
        $result = mysql_query("SELECT *
        FROM Cart
        LEFT JOIN Product
        ON Cart.ProdID = Product.ProductID WHERE Cart.Username='$ppp'");

        echo "<table border='3' id='table' border='1' class='container'>";

        $cnt = 0;
        echo "<tr>";
        echo "<td colspan='9' align='center'><h1>Your Cart</h1></td>";
        echo "</tr>";
        echo "<th>Product Name</th>";
        echo "<th>Brand</th>";
        echo "<th>Price</th>";
        echo "<th>Category</th>";
        echo "<th>Quantity</th>";
        echo "<th colspan='3'></th>";
        echo "<th>Total</th>";
        echo "</tr>";
        while($row = mysql_fetch_array($result))
        {
              echo "<td>" . $row['Name_product'] . "</td>";
              echo "<td>" . $row['Brand'] . "</td>";
              echo "<td>" . $row['Price'] . "</td>";
              echo "<td>" . $row['Category'] . "</td>";
              echo "<td>" . $row['Total_Quantity'] . "</td>";
              ?>
              <form method='post' action="cart.php?action=add&pid=<?php echo $row['ProdID']; ?>">
              <td><input type="submit" value="Inc"></td>
              </form>

              <form method='post' action="cart.php?action=sub&pid=<?php echo $row['ProdID']; ?>">
              <td><input type="submit" value="Dec"></td>
              </form>              

              <form method='post' action="cart.php?action=rem&pid=<?php echo $row['ProdID']; ?>">
              <td><input type="submit" value="Remove"></td>
              </form>
              <?php
              $curr = $row['Price'] * $row['Total_Quantity']; 
              
              $cnt = $cnt + $curr;
              echo "<td>".$curr."</td>";
              echo "</tr>";
        }
        echo "<tr>";
        echo "<td colspan='8'><h1>Grand Total:</h1></td>";
        echo "<td><h1>".$cnt."</h1></td>";
        echo "</tr></table></form>";
    ?>
    <br><br>

    <div class="tattt">
    <a href="pay.php?amt=<?php echo $cnt;?>" class="action-button shadow animate green" style="margin-left:750px;">Proceed to Payment>></a>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <form >
    </form>
</body>

</html>
